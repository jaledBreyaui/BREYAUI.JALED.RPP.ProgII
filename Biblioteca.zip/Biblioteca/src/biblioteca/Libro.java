package biblioteca;

public class Libro extends Publicacion implements Leer {

    private String autor;
    private Genero genero;

    public Libro(String titulo, int anioPublicacion, String autor, Genero genero) {
        super(titulo, anioPublicacion);
        this.autor = autor;
        this.genero = genero;
    }

    @Override
    public String toString() {
        return super.toString() + "[" + "autor=" + autor + ", genero=" + genero + "]";
    }

    public void leer() {
        System.out.println("Leyendo el libro " + getTitulo() + " ...");
    }
}
