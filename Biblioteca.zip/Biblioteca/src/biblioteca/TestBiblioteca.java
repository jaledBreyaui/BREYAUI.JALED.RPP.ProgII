package biblioteca;

public class TestBiblioteca {

    public static void main(String[] args) {
        Biblioteca biblioteca = new Biblioteca();

        try {
            biblioteca.agregarPublicacion(new Revista("Billiken", 2015, 345));
            biblioteca.agregarPublicacion(new Libro("El Facundo", 1881, "Sarmiento", Genero.HISTORIA));
            biblioteca.agregarPublicacion(new Ilustracion("Una ilustracion", 1950, "Quinquela Martin", 0, 0));
        } catch (NullPointerException | PublicacionRepetidaException | IllegalArgumentException e) {
            System.out.println(e.getMessage());
        }
        
        System.out.println("Publicaciones dentro de la biblioteca: ");
        biblioteca.mostrarPublicaciones();

        biblioteca.leerPublicaciones();
    }
}
