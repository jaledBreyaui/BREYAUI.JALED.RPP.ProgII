
package biblioteca;


public interface Leer {
     void leer();
}
