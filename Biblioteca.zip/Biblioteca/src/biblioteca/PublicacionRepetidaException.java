package biblioteca;

public class PublicacionRepetidaException extends RuntimeException {

    private final static String MESSAGE = "Esta publicacion ya se enceuntra dentro de la lista";

    public PublicacionRepetidaException() {
        super(MESSAGE);
    }

}
