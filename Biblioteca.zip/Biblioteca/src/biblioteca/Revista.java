package biblioteca;

public class Revista extends Publicacion implements Leer {

    private int nroEdicion;

    public Revista(String titulo, int anioPublicacion, int nroEdicion) {
        super(titulo, anioPublicacion);
        if (nroEdicion <= 0) {
            throw new IllegalArgumentException("el nro. de edicion debe ser mayor a 0");
        }
        this.nroEdicion = nroEdicion;
    }

    @Override
    public String toString() {
        return super.toString() + "[" + "numeroEdicion=" + nroEdicion + "]";
    }

    public void leer() {
        System.out.println("Leyendo la revista " + getTitulo() + " ...");
    }
}
