package biblioteca;

import java.util.ArrayList;
import java.util.List;

public class Biblioteca {

    private List<Publicacion> publicaciones;

    public Biblioteca() {
        this.publicaciones = new ArrayList<>();
    }

    public void agregarPublicacion(Publicacion publicacion) {
        if (publicacion == null) {
            throw new NullPointerException("Argumento nulo");
        }

        if (!publicacionRepetida(publicacion)) {
            publicaciones.add(publicacion);
            System.out.println("Se agrego la publicacion " + publicacion.getTitulo());
        }

    }

    private boolean publicacionRepetida(Publicacion publicacion) {
        if (publicaciones.contains(publicacion)) {
            throw new PublicacionRepetidaException();
        }
        return false;
    }

    public void mostrarPublicaciones() {
        for (Publicacion p : publicaciones) {
            System.out.println(p);
        }
    }

    public void leerPublicaciones() {
        for (Publicacion publicacion : publicaciones) {
            if (publicacion instanceof Leer l) {
                l.leer();
            } else {
                System.out.println("La publicacion " +  "'" +  publicacion.getTitulo() +"'" + " no es legible");
            }
        }
    }
}
