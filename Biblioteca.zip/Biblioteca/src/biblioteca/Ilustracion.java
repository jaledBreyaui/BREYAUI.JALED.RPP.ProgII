package biblioteca;

public class Ilustracion extends Publicacion {

    private String ilustrador;
    private int ancho;
    private int alto;

    public Ilustracion(String titulo, int anioPublicacion, String ilustrador, int ancho, int alto) {
        super(titulo, anioPublicacion);
        this.ilustrador = ilustrador;
        if (ancho < 0 || alto < 0) {
            throw new IllegalArgumentException("El ancho y alto de la ilustracion debe ser mayor a 0");
        }
        this.ancho = ancho;
        this.alto = alto;
    }

    @Override
    public String toString() {
        return super.toString() + "[" + "ilustrador=" + ilustrador + ", ancho=" + ancho + ", alto=" + alto + "]";
    }

}
